<template>
<div>
    <mt-header fixed title="反馈详情">
        <router-link to="/record" slot="left">
        <mt-button icon="back"></mt-button>
        </router-link>
    </mt-header>
    <mt-cell title="疑似缺陷">2018-11-06</mt-cell>
</div>    
</template>
<script>
export default {
    name: "question"
}
</script>
